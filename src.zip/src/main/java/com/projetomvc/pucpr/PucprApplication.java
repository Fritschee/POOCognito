package com.projetomvc.pucpr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PucprApplication {

	public static void main(String[] args) {
		SpringApplication.run(PucprApplication.class, args);
	}

}
