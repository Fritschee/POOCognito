package com.projetomvc.pucpr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PucprApplicationTests {

	@Test
	void contextLoads() {
	}

}
